
#ifndef TIME_H
#define	TIME_H

#include <xc.h>
#include "timer.h"

#endif	/* TIME_H */