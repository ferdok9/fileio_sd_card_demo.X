#ifndef DATATYPES_H
#define	DATATYPES_H

#define cTrue (1 == 1)
#define cFalse (1 == 0)

#define    sint8     signed char
#define    uint8     unsigned char
#define    sint16    signed int
#define    uint16    unsigned int
#define    sint32    signed long
#define    uint32    unsigned long

//#define    signed long long*
//#define    unsigned long long*

#endif	/* DATATYPES_H */

