/* 
 * File:   GPIO.h
 * Author: ferdok9
 *
 * Created on 18 March 2016, 23:01
 */

#ifndef GPIO_H
#define	GPIO_H

#include <xc.h>

void LedInit(void);

#endif	/* GPIO_H */

